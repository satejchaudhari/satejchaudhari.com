# Satej Chaudhari — security research site

A minimal, dark, professional cybersecurity portfolio built in plain HTML, CSS, and JavaScript — no frameworks, no build step, no npm install. Deployed for free on Cloudflare Pages at **satejchaudhari.com**.

---

## How the site is put together

```
index.html                 → homepage: about + preview of latest writeups & blog posts
writeups.html               → full, filterable list of all writeups
blog.html                    → full, filterable list of all blog posts
toolkit.html                 → searchable master toolkit page
post-template.html           → not used directly — see posts/post-template.html
posts/                        → every writeup and blog post lives here as its own .html file
  post-template.html          → COPY THIS to create a new post
assets/css/style.css          → all styling — the entire visual identity, one file
assets/js/posts.js            → the list of writeups & blog posts (title, date, type, tag, url...)
assets/js/toolkit.js          → the list of tools shown on toolkit.html
assets/js/main.js             → renders homepage previews + writeups.html / blog.html — you never edit this
assets/js/toolkit-main.js     → renders toolkit.html — you never edit this
assets/img/                   → put your images here
```

The site doesn't scan folders (plain HTML/JS can't do that without a server). Instead, `assets/js/posts.js` and `assets/js/toolkit.js` are simple lists you keep up to date by hand — each addition takes about 10 seconds.

---

## Adding a new writeup or blog post

**1. Copy the template**
Duplicate `posts/post-template.html` and give it a clear filename inside `/posts/`, e.g.:
```
posts/2026-07-15-abusing-wsus-for-lateral-movement.html
```

**2. Edit the copy**
Open it and change the parts marked with numbered comments:
- the `<title>` and meta description
- the "back to" link at the top — point it at `../writeups.html` or `../blog.html` depending on the type
- the tag (free text — `RECON`, `WEB`, `AD`, `NOTES`, whatever fits)
- the post title and date
- the content inside `<div class="post-body">` — this is just HTML: `<p>`, `<h2>`, `<ul>`, `<pre><code>`, `<img>`, `<blockquote>` are all pre-styled

**3. Register it in `assets/js/posts.js`**
Add one object to the top of the `POSTS` array:
```js
{
  title: "Abusing WSUS for Lateral Movement",
  url: "posts/2026-07-15-abusing-wsus-for-lateral-movement.html",
  date: "2026-07-15",
  type: "writeup",           // or "blog"
  tag: "WRITEUP",
  description: "How an unauthenticated WSUS server becomes a domain-wide code exec primitive.",
  readTime: "8 min read"
}
```
`type` controls which page it shows up on (`writeups.html` or `blog.html`) and which homepage preview it appears in. `tag` is free text and drives the filter buttons on that page automatically.

**4. Save and check `index.html`, `writeups.html` / `blog.html`** — the new post appears at the top of the relevant list, and if the tag is new, a filter button for it appears automatically.

That's the entire workflow. No commands to run.

---

## Adding a tool to the toolkit

Open `assets/js/toolkit.js` and add an entry to the right category:
```js
{ name: "Tool Name", url: "https://...", description: "One line on what it's for." }
```
Or add a whole new category by adding a new `{ category: "...", tools: [...] }` object to the array. The page — including the search box — rebuilds itself from this file. Double-check URLs before publishing so the page stays a reliable jumping-off point.

---

## Adding images to a post

1. Put the image file in `assets/img/` — organizing by post keeps things tidy, e.g.:
   ```
   assets/img/wsus-lateral-movement/screenshot1.png
   ```
2. Reference it from inside `/posts/your-post.html` (note the `../` since posts live one folder down):
   ```html
   <img src="../assets/img/wsus-lateral-movement/screenshot1.png" alt="Describe the image">
   ```
3. Want a caption under it? Wrap it in a `<figure>`:
   ```html
   <figure>
     <img src="../assets/img/wsus-lateral-movement/screenshot1.png" alt="Describe the image">
     <figcaption>Optional caption text.</figcaption>
   </figure>
   ```

Images are automatically sized to fit the page width, rounded, and bordered to match the rest of the site — no extra styling needed.

---

## Previewing locally before you publish

Because pages load `posts.js` / `toolkit.js` and `main.js` as plain `<script>` tags (not `fetch`), you can just **double-click `index.html`** and it works straight from your file system — no local server required. This also applies to every individual post page and to `toolkit.html`.

---

## Deploying to Cloudflare Pages

Since your domain is already on Cloudflare, this is the smoothest path:

1. Push this folder to a GitHub repo.
2. Cloudflare dashboard → **Workers & Pages** → **Create** → **Pages** → **Connect to Git** → select your repo.
3. Build settings:
   ```
   Framework preset: None
   Build command:    (leave blank)
   Build output directory: /
   ```
   (There's nothing to build — it's static HTML/CSS/JS as-is.)
4. Deploy. You'll get a free `*.pages.dev` URL immediately.
5. In the Pages project → **Custom domains** → **Set up a domain** → enter your domain. Since Cloudflare already manages your DNS, the record is added automatically.

Every future `git push` redeploys the live site within seconds.

---

## Changing the look

Everything visual lives in `assets/css/style.css`, in the `:root { ... }` block at the top:
- `--bg`, `--surface` — background colors
- `--accent` — the single highlight color (tags, buttons, active filters, links on hover)
- `--display` / `--sans` / `--mono` — the three font roles used throughout (headings, body text, labels/code)

Change a value once and it applies sitewide.

---

## Before you go live

Update the placeholders that are still generic:
- `https://github.com/yourusername` in every page's nav and footer
- `https://linkedin.com/in/yourusername` and the `mailto:` address in the About section on `index.html`
- The bio text in the About section on `index.html`
- Toolkit URLs in `assets/js/toolkit.js` — verify each one still points where you expect

All canonical links and Open Graph tags are already set to `https://satejchaudhari.com/...` — if you deploy under a different domain, update those too (one `<link rel="canonical">` and a few `og:url` tags per page).

---

## Notes

- No comments, analytics, or tracking are included — this is intentionally a plain, fast, static site.
- Tags are free text — use whatever categories make sense to you; the filter bar on `writeups.html` / `blog.html` builds itself from whatever's actually in `posts.js`.
- There's no database and no server-side code, so there's nothing to secure or patch beyond keeping the static files themselves sane.
